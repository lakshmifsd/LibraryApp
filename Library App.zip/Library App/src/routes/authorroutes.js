const express = require('express');

const authorRouter = express.Router();
function router(nav){
  var authors= [
    {
       
        author:'Arundhati Roy',
       
        img:"arundhathi.jpg"
    },
    {   
      
        author:'Chethan Bhagat',
        
        img:"chethan.jpg"
    },
    {
      
        author:'Paulo Coelho',
    
        img:"paulo.jpg"
    },
    {
       
        author:'Lewis Carroll',
       
        img:"lewis.jpg"
    }
]
authorsRouter.get('/',function(req,res){
res.render("author",{
    nav,
   title:'Library',
authors
});

});

authorsRouter.get('/:id',function(req,res){
    const id=req.params.id
    res.render('author',{
    nav,
    title:'Library',
    author:authors[id]
    });
  
  });

  return authorRouter;
  

}

module.exports = router;

 
