const express = require('express');

const booksRouter = express.Router();
function router(nav){
  var books = [
    {
        title:'The God of Small Things',
        author:'Arundhati Roy',
        genre:'Novel',
        img:"small.jpg"
    },
    {   
        title:'One Arranged Murder',
        author:'Chethan Bhagat',
        genre:'Novel',
        img:"one.jpg"
    },
    {
        title:'The Alchemist',
        author:'paulo Coelho',
        genre:'Novel',
        img:"alchemist.jpg"
    },
    {
        title:'Alices Adventures in Wonderland',
        author:'Lewis Carroll',
        genre:'Cartoon',
        img:"Alice.jpg"
    }
]
booksRouter.get('/',function(req,res){
res.render("books",{
    nav,
   title:'Library',
books
});

});

booksRouter.get('/:id',function(req,res){
    const id=req.params.id
    res.render('book',{
    nav,
    title:'Library',
    book:books[id]
    });
  
  });

  return booksRouter;
  

}
module.exports = router;

 
