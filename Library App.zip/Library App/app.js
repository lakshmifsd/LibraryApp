const { urlencoded } = require('express');
const express=require('express');
const authorRouter = require('./src/routes/authorroutes');
const bookRouter = require('./src/routes/bookroutes');
const signupRouter = require('./src/routes/signuproutes');
const loginRouter = require('./src/routes/loginroutes');


const app = new express();
const port = process.env.PORT||8000;

const nav = [
    {link:"/index",name:"Home" },
    {link:"/books",name:"Books" },
    {link:"/authors",name:"Authors"},
    {link:"/signup",name:"signup"},
    {link:"/login",name:"Login"},
  ];


const booksRouter = require('./src/routes/bookroutes')(nav)
const authorRouter = require('./src/routes/authorroutes')(nav)
const signupRouter = require('./src/routes/signuproutes')(nav)
const loginRouter = require('./src/routes/loginoutes')(nav)
const addbookRouter = require('./src/routes/addbooknoutes')(nav)


app.use(express.static('./public'));
app.set('view engine','ejs');
app.set('views', __dirname+'/src/views');
app.use('/books',booksRouter);
app.use('/authors',authorRouter);
app.use('/signup',signupRouter);
app.use('/login',loginRouter);



app.get('/',(req,res)=>
        {
         res.render("index",{nav});
        });
    
app.listen(port,()=>(console.log("Server Ready at" + port)});
